The makefile has been phased out, and replaced with CMakeLists.txt.
It will be left as is for those who prefer make over cmake, but it will no longer be maintained.